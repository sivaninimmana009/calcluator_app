from flask import Flask, render_template, flash, request, url_for, redirect, session, g
from content_management import Content

from functools import wraps
from flask_wtf import Form


TOPIC_DICT = Content()

app = Flask(__name__)


app.secret_key = 'my unobvious secret key'


@app.route('/dashboard/')
def dashboard():
    flash('flash test!!!')

    return render_template('dashboard.html', TOPIC_DICT=TOPIC_DICT)







if __name__ == '__main__':
    app.run(debug=True,port=5050)
