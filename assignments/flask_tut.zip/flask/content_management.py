
def Content():
    TOPIC_DICT = {"Basics":[['Introduction to Python','/introduction-to-python'],
                            ['Print functions and Strings','/python-functions-and-strings']],
                'Web Dev':[]}

    return TOPIC_DICT
